package ColorCalibration;

import static ColorCalibration.Resources.BASE_WIDTH;
import static ColorCalibration.Resources.ROTATE_SPEED;
import static ColorCalibration.Resources.WHEEL_RAD;
import static ColorCalibration.Resources.leftMotor;
import static ColorCalibration.Resources.rightMotor;
import java.util.ArrayList;
import lejos.hardware.Sound;

public class Navigation implements Runnable{

	/**
	 * The colors detected
	 */
	public static ArrayList<String> colors_detected = new ArrayList<>();
	
	/**
	 * Contructor of Navigation must receive an array of waypoints to navigate to.
	 * @param waypoints Array of Waypoint objects.
	 */
	public Navigation() {
		
	}

	@Override
	public void run() {
		
		setSpeed(ROTATE_SPEED);
		
		leftMotor.forward();
		rightMotor.forward();
		
		while(true) {
			if(Main.color != "GROUND") {
				stopMotors();
				Sound.setVolume(1);
				Sound.twoBeeps();
				colors_detected.add(Main.color);
				Main.sleepFor(10000);
		
			} else {
				leftMotor.forward();
				rightMotor.forward();
			}
		}

	}


	public void turnBy(double theta) {

		leftMotor.rotate(convertAngle(theta), true);
		rightMotor.rotate(-convertAngle(theta), false);
		

	}


	/**
	 * Stops both motors.
	 */
	public static void stopMotors() {
		leftMotor.stop(true);
		rightMotor.stop();
	}

	/**
	 * Moves the robot straight for the given distance.
	 * 
	 * @param distance in feet (tile sizes), may be negative
	 */
	public static void moveStraightFor(double distance) {
		leftMotor.rotate(convertDistance(distance), true);
		rightMotor.rotate(convertDistance(distance), false);
	}

	/**
	 * Converts input distance to the total rotation of each wheel needed to cover that distance.
	 * 
	 * @param distance the input distance
	 * @return the wheel rotations necessary to cover the distance
	 */
	public static int convertDistance(double distance) {
		return (int) ((180.0 * distance) / (Math.PI * WHEEL_RAD));
	}

	/**
	 * Converts input angle to the total rotation of each wheel needed to rotate the robot by that
	 * angle.
	 * 
	 * @param angle the input angle
	 * @return the wheel rotations necessary to rotate the robot by the angle
	 */
	public static int convertAngle(double angle) {
		return convertDistance(Math.PI * BASE_WIDTH * angle / 360.0);
	}

	/**
	 * Sets the speed of both motors to the same values.
	 * 
	 * @param speed the speed in degrees per second
	 */
	public static void setSpeed(int speed) {
		setSpeeds(speed, speed);
	}

	/**
	 * Sets the speed of both motors to different values.
	 * 
	 * @param leftSpeed the speed of the left motor in degrees per second
	 * @param rightSpeed the speed of the right motor in degrees per second
	 */
	public static void setSpeeds(int leftSpeed, int rightSpeed) {
		leftMotor.setSpeed(leftSpeed);
		rightMotor.setSpeed(rightSpeed);
	}

//
//	/**
//	 * Returns the filtered distance between the US sensor and an obstacle in cm.
//	 * 
//	 * @return the filtered distance between the US sensor and an obstacle in cm
//	 */
//	public int readUsDistance() {
//		usSensor.fetchSample(usData, 0);
//		// extract from buffer, convert to cm, cast to int, and filter
//		return filter((int) (usData[0] * 100.0));
//	}
//
//	/**
//	 * Rudimentary filter - toss out invalid samples corresponding to null signal.
//	 * 
//	 * @param distance raw distance measured by the sensor in cm
//	 * @return the filtered distance in cm
//	 */
//	int filter(int distance) {
//		if (distance >= 255 && invalidSampleCount < INVALID_SAMPLE_LIMIT) {
//			// bad value, increment the filter value and return the distance remembered from before
//			invalidSampleCount++;
//			return prevDistance;
//		} else {
//			if (distance < 255) {
//				// distance went below 255: reset filter and remember the input distance.
//				invalidSampleCount = 0;
//			}
//			prevDistance = distance;
//			return distance;
//		}
//	}
//
}
