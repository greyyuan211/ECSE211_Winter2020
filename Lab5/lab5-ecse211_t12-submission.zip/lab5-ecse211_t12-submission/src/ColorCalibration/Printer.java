package ColorCalibration;

import static ColorCalibration.Resources.*;
import static ColorCalibration.Main.*;


/**
 * The printer thread prints status information in the background. Since the thread sleeps for 
 * 200 ms each time through the loop, screen updating is limited to 5 Hz.
 */
public class Printer implements Runnable {

	/**
	 * Printer sleep time in ms.
	 */
	private static final int SLEEP_TIME = 200; 

	public Printer() {

	}

	public void run() {
		while (true) { // operates continuously
			TEXT_LCD.clear();

			// print last US reading
			TEXT_LCD.drawString("red     : " + (int) (colorSamples[0] * 1000), 0, 0);
			TEXT_LCD.drawString("green : " +(int) ( colorSamples[1] * 1000), 0, 1);
			TEXT_LCD.drawString("blue    : " + (int)  (colorSamples[2] * 1000), 0, 2);
			TEXT_LCD.drawString("color    : " + Main.color, 0, 3);



			Main.sleepFor(POLL_SLEEP_TIME);
		}
	}

	/**
	 * Prints the main menu. Note that this is a static method.
	 */
	public static void printMainMenu() {
		TEXT_LCD.clear();
		TEXT_LCD.drawString("touch me", 0, 0);
	}
	
	public static void printFinalMenu() {
		TEXT_LCD.clear();
		TEXT_LCD.drawString("Number detected: " + Navigation.colors_detected.size(), 0, 0);
		for(int i = 0; i < Navigation.colors_detected.size(); i++) {
			TEXT_LCD.drawString(Navigation.colors_detected.get(i), i, 1);
		}
		
	}
}
