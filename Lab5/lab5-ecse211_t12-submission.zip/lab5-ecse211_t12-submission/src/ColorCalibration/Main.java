package ColorCalibration;

import static ColorCalibration.Resources.*;
import static ColorCalibration.Printer.*;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.util.Dictionary;
import java.util.Hashtable;
import ColorCalibration.Navigation;
import ColorCalibration.Printer;
import lejos.hardware.Button;


public class Main {
	
	public static float[] colorSamples = new float[myColorSample.sampleSize()];
	
	public static Printer printer;
	
	public static Thread printerThread;
	
	/**
	 * Handles the navigation of the robot through the maps.
	 */
	public static Navigation navigation;
	
	/**
	   * Dictionary to store the rings RGB arrays and easy retrieval from their color
	   * which is going to be the key in the dict.
	   */
	public static Dictionary<String, double[]> RINGS_RGB_NORM = new Hashtable<String, double[]>();
	  
	public static String color = "";
	
	public static double minimal_dist = 0;
	
	/**
	 * The main entry point.
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		Button.waitForAnyPress();
		
		endProgram();
		
		printer = new Printer();
		printerThread = new Thread(printer);
		printerThread.start();
		
		RINGS_RGB_NORM.put("YELLOW", YELLOW_RING_RGB_NORM);
		RINGS_RGB_NORM.put("BLUE", BLUE_RING_RGB_NORM);
		RINGS_RGB_NORM.put("ORANGE", ORANGE_RING_RGB_NORM);
		RINGS_RGB_NORM.put("GREEN", GREEN_RING_RGB_NORM);
		
		
		double[] RGB_array = new double[3];
		
		while(true) {
			myColorSample.fetchSample(colorSamples, 0);
			RGB_array[0] = (double) colorSamples[0];
			RGB_array[1] = (double) colorSamples[1];
			RGB_array[2] = (double) colorSamples[2];
			
			// normalize the rgb array
			normalize_RGB_array(RGB_array);
			
			double yellow_ring_dist = euclidian_distance(RGB_array, "YELLOW");
			double blue_ring_dist = euclidian_distance(RGB_array, "BLUE");
			double orange_ring_dist = euclidian_distance(RGB_array, "ORANGE");
			double green_ring_dist = euclidian_distance(RGB_array, "GREEN");
			
			
			double minimal_dist_temp1 = Math.min(yellow_ring_dist, blue_ring_dist);
			double minimal_dist_temp2 = Math.min(orange_ring_dist, green_ring_dist);
			minimal_dist = Math.min(minimal_dist_temp1, minimal_dist_temp2);
			
			
			// we have now found the minimal euclidian distance
			// find the color associated with the distance
			if(minimal_dist >= GROUND_EUCLIDIAN_DIST)	
				color = "GROUND";
			else if(minimal_dist == yellow_ring_dist) 
				color = "YELLOW";
			else if(minimal_dist == blue_ring_dist) 
				color = "BLUE";
			else if(minimal_dist == orange_ring_dist) 
				color = "ORANGE";
			else if(minimal_dist == green_ring_dist) 
				color = "GREEN";

			sleepFor(POLL_SLEEP_TIME);
		}
	}
	
	/**
	 * Method to compute the euclidian distance between the sample measurements
	 * and the absolute measurement stored in Resources.
	 */
	public static double euclidian_distance(double[] RGB_array, String color) {
		double[] RING_RGB_NORM = RINGS_RGB_NORM.get(color.toUpperCase());
		
		double red_diff = RGB_array[0] - RING_RGB_NORM[0];
		double green_diff = RGB_array[1] - RING_RGB_NORM[1];
		double orange_diff = RGB_array[2] - RING_RGB_NORM[2];
		
		double eucl_dist =  sqrt(pow(red_diff,2) + pow(green_diff,2) + pow(orange_diff,2));
		return eucl_dist;
	}
	
	
	/**
	 * Method to modify a RGB array to a normalized RGB array
	 * @param RGB_array
	 */
	public static void normalize_RGB_array(double[] RGB_array) {
		assert RGB_array.length == 3;
		
		double R = RGB_array[0];
		double G = RGB_array[1];
		double B = RGB_array[2];
		
		double normalizor = sqrt(pow(R,2) + pow(G,2) + pow(B,2));
		
		if (normalizor == 0) {
			RGB_array[0] = 0;
			RGB_array[1] = 0;
			RGB_array[2] = 0;
			return;
		}
		
		for(int i = 0; i < RGB_array.length; i++) {
			
			RGB_array[i] /= normalizor;
			
		}
		
	}
	
	public static void endProgram() {
		new Thread() {
			public void run() {
				int bid = Button.waitForAnyPress();
				if (bid == Button.ID_ESCAPE) {
					systemExit();
				}
					
			}
		}.start();
	}
	
	public static void systemExit() {
		System.exit(0);
	}

	/**
	 * Sleeps for the specified duration.
	 * @param millis the duration in milliseconds
	 */
	public static void sleepFor(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			// Nothing to do here
		}
	}
}