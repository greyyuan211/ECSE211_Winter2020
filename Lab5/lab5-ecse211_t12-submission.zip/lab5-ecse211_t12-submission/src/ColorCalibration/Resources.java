package ColorCalibration;

import java.util.HashSet;
import java.util.Set;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;

/**
 * This class is used to define static resources in one place for easy access and to avoid
 * cluttering the rest of the codebase. All resources can be imported at once like this:
 * 
 * <p>{@code import static ca.mcgill.ecse211.lab3.Resources.*;}
 */
public class Resources {
  
  /**
   * The wheel radius in centimeters.
   */
  public static final double WHEEL_RAD = 2.0;
  
  /**
   * The robot width in centimeters.
   */
  public static final double BASE_WIDTH = 11;
  
  /**
   * Distance of the color sensor from the axis of rotation of the robot
   */
  public static final double COLOR_SENSOR_DISTANCE = 13.5;
  
  /**
   * The tile size in centimeters. Note that 30.48 cm = 1 ft.
   */
  public static final double TILE_SIZE = 30;
  
  /**
   * The left motor.
   */
  public static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(MotorPort.A);

  /**
   * The right motor.
   */
  public static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(MotorPort.D);
  
  /**
   * The LCD.
   */
  public static final TextLCD TEXT_LCD = LocalEV3.get().getTextLCD();
  
  /**
   * The ultrasonic sensor.
   */
  public static final EV3UltrasonicSensor usSensor = new EV3UltrasonicSensor(SensorPort.S1);
  
  /**
   * The color sensor
   */
  public static  final EV3ColorSensor colorSensor = new EV3ColorSensor(SensorPort.S4);
  
  public static final SampleProvider myColorSample = colorSensor.getRGBMode();
  
  
  /**
   * The speed at which the robot moves forward in degrees per second.
   */
  public static final int INITIAL_SPEED = 100;
  
  /**
   *  Speed at which the robot rotates
   */
  public static final int ROTATE_SPEED = 100;
  
  /**
   * The limit of invalid samples that we read from the US sensor before assuming no obstacle.
   */
  public static final int INVALID_SAMPLE_LIMIT = 20;
  
  /**
   * The poll sleep time, in milliseconds.
   */
  public static final int POLL_SLEEP_TIME = 100;
  
  /**
   * The odometer.
   */
  public static Odometer odometer = Odometer.getOdometer();
  
  /**
   * correction angle to accommodate for laser's lack of precision
   */
  public static double ANGLE_CORRECTION = -1;
  
  /**
   * correction of sensor to body distance error
   */
  public static double DISTANCE_CORRECTION = 13.5;
  
  /**
   * limit distance to detect a wall
   */
  public static int WALL_THRESHOLD = 20;
  
  /**
   * Sleep time to ensure the robot has the time to process everything before the next step.
   */
  public static int REST_SLEEP = 500;
  
  /**
   * The normalized RGB of the yellow ring over 25 samples
   */
  public static final double[] YELLOW_RING_RGB_NORM = {0.863069756, 0.493870018, 0.105844231};
  
  /**
   * The normalized RGB of the blue ring over 25 samples
   */
  public static final double[] BLUE_RING_RGB_NORM = {0.205954751, 0.719722311, 0.663010133};
  
  /**
   * The normalized RGB of the orange ring over 25 samples
   */
  public static final double[] ORANGE_RING_RGB_NORM = {0.957472214, 0.276448074, 0.082604006};
 
  /**
   * The normalized RGB of the green ring over 25 samples
   */
  public static final double[] GREEN_RING_RGB_NORM = {0.465080244, 0.876811203, 0.122075719};
  
  /**
   * Minimal distance considered as the ground when measuring RGB from the rings.
   */
  public static final double GROUND_EUCLIDIAN_DIST = 0.08;
  
}
