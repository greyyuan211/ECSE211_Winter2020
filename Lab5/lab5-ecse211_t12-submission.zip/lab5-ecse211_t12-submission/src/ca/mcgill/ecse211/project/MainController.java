package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import lejos.hardware.Sound;


public class MainController implements Runnable {

  /**
   * Option for selecting mode.
   */
  private int option;

  /**
   * Option for light constant localization. True == brown board, False == Blue board.
   */
  private boolean red = false;

  /**
   * Display thread for stopping or starting the thread.
   */
  private static Thread display;

  /**
   * Records of all the maps given from the lab document.
   */
  private int[][][] paths =
      {{{1, 7}, {3, 4}, {7, 7}, {7, 4}, {4, 1}}, {{5, 4}, {1, 7}, {7, 7}, {7, 4}, {4, 1}},
          {{3, 1}, {7, 4}, {7, 7}, {1, 7}, {1, 4}}, {{1, 4}, {3, 7}, {3, 1}, {7, 4}, {7, 7}},
          {{1, 2}, {2, 3}, {2, 1}, {3, 2}, {3, 3}}, {{1, 3}, {2, 2}, {3, 3}, {3, 2}, {2, 1}}};

  /**
   * Constructor for the class. Set the option entered by the user.
   * 
   * @param option for setup
   */
  public MainController(int option) {
    this.option = option;
    LightController.setRed(red);
  }

  /**
   * Run the corresponding mode based on the option.
   * 
   * @see java.lang.Thread#run()
   */
  public void run() {
    if (this.option == 0) {
      main();
    } else if (this.option == 1) {
      initialLocalization();
    } else if (this.option == 2) {
      lightLocalization();
    } else if (this.option == 3) {
      calibrateAngle();
    } else if (this.option == 4) {
      calibrateDistance();
    } else if (this.option == 5) {
      calibrateColorSensor();
    } else if (this.option == 6) {
      calibrateLightSensor();
    }

  }

  /**
   * For testing the initial localization.
   */
  private void initialLocalization() {
    Navigation.initialLocalization();
  }

  /**
   * Mode for testing the light localization.
   */
  private void lightLocalization() {
    Navigation.lightLocalization();
  }

  /**
   * Primary mode for lab
   */
  private void main() {
    // Perform initial localization
    Navigation.initialLocalization();
    // init the odometer at the init position
    new Thread(odometer).start();

    // start the color detection thread, it will stop the
    // colorController = new ColorDetectionController();
    // new Thread(colorController).start();
    //
    ColorDetectionController.initNorm();
    Navigation.initializeOdometer();
    startDisplay();
    // Sleep until the display is shown
    Main.sleepFor(DEFAULT_SLEEP_TIME);
    // Iterate through each way point
    for (int[] path : paths[0]) {
      // convert the waypoint to coordinate
      double x = Navigation.gridToCord(path[0]);
      double y = Navigation.gridToCord(path[1]);
      // Call the travel to method without blocking (immediate return)
      Navigation.travelTo(x, y, false);
      while(rightMotor.isMoving()) {
        if(ColorDetectionController.isColor()) {
          ColorDetectionController.stopAndDisplayColor();
          Navigation.travelTo(x, y, false);
        }
        Main.sleepFor(CS_POLL_SLEEP_TIME);
      }
      Navigation.lightLocalization();
    }
    Sound.beep();
    Main.sleepFor(50);
    Sound.beep();
    Main.sleepFor(50);
    Sound.beep();
    Main.sleepFor(50);
    ColorDetectionController.showColors();
  }

  /**
   * Wheel angle and odometer calibration mode. Perform 2 full rotation turn and test the accuracy
   * of the turn.
   */
  private void calibrateAngle() {
    new Thread(odometer).start();
    Navigation.initializeOdometer();
    new Thread(new Display()).start();
    Main.sleepFor(DEFAULT_SLEEP_TIME);
    DriverUtil.setSpeed(ROTATE_SPEED);
    DriverUtil.turnBy(2 * FULL_ROTATION);
  }

  /**
   * Wheel angle and odometer calibration mode. Perform 2 full rotation turn and test the accuracy
   * of the turn.
   */
  private void calibrateDistance() {
    new Thread(odometer).start();
    Navigation.initializeOdometer();
    new Thread(new Display()).start();
    Main.sleepFor(DEFAULT_SLEEP_TIME);
    DriverUtil.setSpeed(FORWARD_SPEED);
    DriverUtil.moveStraightFor(TILE_SIZE * 6, true);
  }

  /**
   * Calibrate the light sensor in the back to get the average value.
   */
  private void calibrateLightSensor() {
    double averageIntensity = LightController.calibrateLightSensor();
    Display.showText(new String[] {"Avg light I:", "" + averageIntensity});
    Main.sleepFor(4000); // sleep for 4 second for user to see and record value;
    System.out.println("Avg light I:" + "" + averageIntensity);
  }

  /**
   * Calibrate the color sensor in the back to get the average value.
   */
  private void calibrateColorSensor() {
    double[] averageIntensity = ColorDetectionController.calibrateColorSensor();
    Display.showText(new String[] {"Avg R:", "" + averageIntensity[0], "Avg G:",
        "" + averageIntensity[1], "Avg B:", "" + averageIntensity[2]});
    Main.sleepFor(4000); // sleep for 4 second for user to see and record value;
    System.out.println("Avg R:" + averageIntensity[0] + "\n Avg G:" + averageIntensity[1]
        + "\n Avg B: " + averageIntensity[2]);
  }

  /**
   * Start the display thread
   */
  static void startDisplay() {
    displayController = new Display();
    display = new Thread(displayController);
    display.start();
  }

  /**
   * Stop the display thread
   */
  static void stopDisplay() {
    displayController.stopDisplay();
  }
}
