package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import lejos.hardware.Sound;
import lejos.hardware.lcd.LCD;
import java.util.ArrayList;

public class LightController implements Runnable {

  /**
   * 
   */
  private static float[] colordata = new float[lightSensor.getRedMode().sampleSize()];


  /**
   * The tick where the first black was detected.
   */
  private long blackTick = -1;

  /**
   * The number of measurement the black tick is associated with. Used to calculate the middle
   * point.
   */
  private long width = 0;

  /**
   * Board color for the big board.
   */
  private static double boardColor;

  /**
   * the standard deviation which the value detected is still consider board.
   */
  private static double range;

  /**
   * A boolean to keep end the thread.
   */
  private volatile boolean active = true;

  /**
   * Record the ticks that black stripe occured.
   */
  ArrayList<Long> blackTicks = new ArrayList<>();

  public static double calibrateLightSensor() {
    double sum = 0;
    for (int i = 0; i < CALIBRATION_SAMPLE; i++) {
      lightSensor.getRedMode().fetchSample(colordata, 0);
      sum += colordata[0] * 100.0;
      Main.sleepFor(CS_POLL_SLEEP_TIME);
    }
    sum = sum / CALIBRATION_SAMPLE;
    return sum;
  }

  /**
   * Constantly poll the sensor and sleep
   */
  public void run() {
    while (active) {
      readAndUpdate();
      Main.sleepFor(CS_POLL_SLEEP_TIME);
    }
  }

  /**
   * Reset the controller parameters for the next use
   */
  public void reset() {
    active = true;
    blackTicks = new ArrayList<Long>();
    width = 0;
    blackTick = -1;
  }

  /**
   * Stop the controller by setting the active flag
   */
  public void stopController() {
    active = false;
  }

  /**
   * Read the color sensor and update the value
   */
  private void readAndUpdate() {
    lightSensor.getRedMode().fetchSample(colordata, 0);
    float cid = colordata[0] * 100;
    boolean black = !isWithinInterval(cid, boardColor, range);
    LCD.clear();
    if (black) {
      if (width == 0) {
        Sound.beep();
        blackTick = System.currentTimeMillis();
      }
      width = System.currentTimeMillis();
    } else {
      if (width != 0) {
        long tick = (blackTick + width) / 2;
        blackTicks.add(tick);
        blackTick = -1;
        width = 0;
      }
    }
  }

  /**
   * Return the ticks that black occured
   * 
   * @return the tick
   */
  public ArrayList<Long> getBlackTicks() {
    return blackTicks;
  }

  public static void setRed(boolean red) {
    if (!red) {
      boardColor = BLUE_BOARD;
      range = BLUE_BOARD_RANGE;
    } else {
      boardColor = BROWN_BOARD;
      range = BROWN_BOARD_RANGE;
    }
  }

  /**
   * The moveUntilLine method moves forward or backward until a line is detected.
   * 
   * @param forward : true to move forward, false to move backward
   * @param delay : delay in ms to wait until after the line is detected
   * @param pos : 0 if the axis to be crossed is the x-axis, 1 for y
   */
  public static void moveUntilLine(boolean forward) {
    if (forward) {
      leftMotor.forward();
      rightMotor.forward();
    } else {
      leftMotor.backward();
      rightMotor.backward();
    }
    lightSensor.getRedMode().fetchSample(colordata, 0);
    double cid = colordata[0];
    // Let the motors go forward/backward until the sensor senses a black line.
    while (!isWithinInterval(cid, 13, 0.5)) {
      lightSensor.getRedMode().fetchSample(colordata, 0);
      cid = colordata[0];
    }
    // The delay allows the robot to move slightly past the black line before
    // stopping,
    // to avoid accidentally reading the same line twice in a row.
    // Main.sleepFor(DEFAULT_SLEEP_TIME);

    leftMotor.stop(true);
    rightMotor.stop();
  }

  /**
   * The moveUntilLine method moves turn clockwise or counter clockwise until a line is detected.
   * 
   * @param clockwise : true to move clockwise, false to move counter-clockwise
   */
  public static void turnUntilLine(boolean clockwise) {
    colordata = new float[lightSensor.getRedMode().sampleSize()];
    DriverUtil.setSpeed(CS_SMALL_ROTATION_SPEED);
    if (clockwise) {
      leftMotor.forward();
      rightMotor.backward();
    } else {
      leftMotor.backward();
      rightMotor.forward();
    }
    // Let the motors go forward/backward until the sensor senses a black line.
    lightSensor.getRedMode().fetchSample(colordata, 0);
    double cid = colordata[0] * 100;
    // Let the motors go forward/backward until the sensor senses a black line.
    while (isWithinInterval(cid, boardColor, range)) {
      lightSensor.getRedMode().fetchSample(colordata, 0);
      cid = colordata[0] * 100;
    }
//    Main.sleepFor(100);
    leftMotor.stop(true);
    rightMotor.stop();
    DriverUtil.setSpeed(FORWARD_SPEED);
  }

  /**
   * check if value is within the interval
   * 
   * @param value
   * @param center
   * @param offset
   * @return value within interval
   */
  private static boolean isWithinInterval(double value, double center, double offset) {
    return value >= center - offset && value <= center + offset;
  }
}
