package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import java.util.ArrayList;

public class Navigation {

  /**
   * The US controller thread to poll and provide information.
   */
  private static Thread ultrasonicThread;

  /**
   * The CS controller thread to poll and provide information.
   */
  private static Thread lightThread;

  /**
   * Initialize the location to the default starting parameter in the odometer.
   */
  public static void initializeOdometer() {
    odometer.setX(sX);
    odometer.setY(sY);
    odometer.setTheta(sT);
  }

  /**
   * Convert grid coordinate to actual coordinate (cm).
   * 
   * @param ind
   * @return actual distance (cm)
   */
  public static double gridToCord(int ind) {
    return ind * TILE_SIZE;
  }

  /**
   * Perform a operation to travel to a specified location based on the odometer. and user input
   * 
   * @param x
   * @param y
   */
  public static void travelTo(double x, double y, boolean blocking) {
    double[] xyt = odometer.getXyt();
    double curX = xyt[0];
    double curY = xyt[1];
    double deltaX = x - curX;
    double deltaY = y - curY;
    double angle = Math.toDegrees(Math.atan2(deltaX, deltaY));
    double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    turnTo(angle);
    DriverUtil.setSpeed(FORWARD_SPEED);
    DriverUtil.moveStraightFor(distance, blocking);
  }
  
  /**
   * Rotate to the given angle base on the current odometer data
   * 
   * @param angle
   */
  public static void turnTo(double angle) {
    double[] xyt = odometer.getXyt();
    double currentTheta = xyt[2];
    double angleToturn = angle - currentTheta;
    // get the minimum angle
    if (angleToturn > 180) {
      angleToturn = angleToturn - 360.0;
    } else if (angleToturn < -180.0) {
      angleToturn = 360.0 + angleToturn;
    }
    DriverUtil.setSpeed(ROTATE_SPEED);
    DriverUtil.turnBy(angleToturn);
  }

  /**
   * Round the position after a color sensor localization
   */
  private static void roundPosition() {
    double[] xyt = odometer.getXyt();
    double roundedX = TILE_SIZE * Math.round(xyt[0] / TILE_SIZE);
    double roundedY = TILE_SIZE * Math.round(xyt[1] / TILE_SIZE);
    double roundedTheta = (RIGHT_ANGLE_ROTATION * Math.round(xyt[2] / RIGHT_ANGLE_ROTATION)) % 360;
    odometer.setX(roundedX);
    odometer.setY(roundedY);
    odometer.setTheta(roundedTheta);
  }

  /**
   * Localize using the light sensor
   */
  public static void lightLocalization() {
    // Start the us controller
    DriverUtil.setSpeed(CS_ROTATE_SPEED);
    lightController = new LightController();
    lightThread = new Thread(lightController);
    lightThread.start();
    lightController.reset();
    long initialTime = System.currentTimeMillis();
    DriverUtil.turnBy(FULL_ROTATION);
    long totalTick = System.currentTimeMillis() - initialTime;
    ArrayList<Long> ticks = lightController.getBlackTicks();
    double offset = 2;
    while (ticks.size() < 4) {
      DriverUtil.moveStraightFor(offset, true);
      lightController.reset();
      initialTime = System.currentTimeMillis();
      DriverUtil.turnBy(FULL_ROTATION);
      totalTick = System.currentTimeMillis() - initialTime;
      ticks = lightController.getBlackTicks();
      int sign = offset > 0.0 ? -1 : 1;
      offset = sign * Math.abs(offset + 2);
    }
    lightController.stopController();
    for (int i = 0; i < 4; i++) {
      ticks.set(i, ticks.get(i) - initialTime);
    }
    tickLocalize(ticks, totalTick);
    DriverUtil.turnBy(CS_SMALL_ROTATION);
    LightController.turnUntilLine(false);
    roundPosition();
  }

  /**
   * Localized based on tick received from the color sensor.
   * 
   * @param an array list of tick where black line was detected.
   * @param total amount of tick made throughout the 360 degree turn.
   */
  private static void tickLocalize(ArrayList<Long> ticks, long totalTick) {
    // Perform x correction
    double angle = (ticks.get(0) * FULL_ROTATION) / totalTick;
    double deltaTheta = getDTheta(ticks.get(0), ticks.get(2), totalTick);
    double angletoTurn = angle + deltaTheta;
    DriverUtil.turnBy(angletoTurn);
    double offset = COLOR_SENSOR_CENTER_OFFSET * Math.cos(Math.toRadians(deltaTheta));
    DriverUtil.moveStraightFor(-offset, true);
    // Perform the y correction
    angle = (ticks.get(1) * FULL_ROTATION) / totalTick;
    deltaTheta = getDTheta(ticks.get(1), ticks.get(3), totalTick);
    angletoTurn = angle - angletoTurn + deltaTheta;
    DriverUtil.turnBy(angletoTurn);
    offset = COLOR_SENSOR_CENTER_OFFSET * Math.cos(Math.toRadians(deltaTheta));
    DriverUtil.moveStraightFor(-offset, true);
  }

  /**
   * Perform the computation and return the delta angle. uses angle between the two tick from color
   * sensor
   * 
   * @param first tick that black line was detected
   * @param opposite tick that black line was detected
   * @param total amount of tick made
   * @return the delta angle from the first line position to facing the line
   */
  private static double getDTheta(long tick1, long tick2, long totalTick) {

    double dtheta = (tick2 - tick1) * 360.0 / totalTick;
    if (dtheta > 180.0) {
      dtheta = dtheta - 360.0;
    }
    dtheta /= 2.0;
    return dtheta;
  }

  /**
   * The initial Localization. Uses ultrasonic detection twice and find the min and travel distance
   * based on sensor data.
   */
  public static void initialLocalization() {
    // Start the us controller
    ultraSonicController = new UltraSonicController();
    ultrasonicThread = new Thread(ultraSonicController);
    ultrasonicThread.start();
    // perform the following operation 2 time. Face the closest wall and backup
    // until a suitable
    // distance based on the us sensor
    faceTheClosestWall();
    backup();
    // Now the robot is in position with respect to one direction x or y.
    // perform turn to fix the position of the other direction.
    DriverUtil.turnBy(RIGHT_ANGLE_ROTATION);
    if (ultraSonicController.getCurDist() < DISTANCE_THRESHOLD) {
      minorAngleCorrection();
      backup();
      DriverUtil.turnBy(RIGHT_ANGLE_ROTATION);
    } else {
      DriverUtil.turnBy(-U_TURN_ROTATION);
      minorAngleCorrection();
      backup();
      DriverUtil.turnBy(-U_TURN_ROTATION);
    }
    ultraSonicController.stopController();
    DriverUtil.setSpeed(CS_SMALL_ROTATION_SPEED);
    DriverUtil.turnBy(CS_SMALL_ROTATION);
    LightController.turnUntilLine(false);
  }

  /**
   * Helper method to face towards the closest wall. Perform a 360 sweep to turn to the aggregate
   * angle and a slow 60 degree sweep to turn get a accurate turn.
   */
  private static void faceTheClosestWall() {
    // perform 360 turn and locate the approximate angle and use minor correction to
    // determine the
    // exact angle.
    DriverUtil.setSpeed(ROTATE_SPEED);
    ultraSonicController.reset();
    long initialTime = System.currentTimeMillis();
    DriverUtil.turnBy(FULL_ROTATION);
    long totalTic = System.currentTimeMillis() - initialTime;
    long minTic = ultraSonicController.getAvgMinDistIndex() - initialTime;
    double angleToTurn = 0;
    // locate the angle away from the start position.
    angleToTurn = ((double) minTic) * FULL_ROTATION / totalTic;
    if (angleToTurn > 180.0) {
      angleToTurn = angleToTurn - 360.0;
    } // perform the turn
    DriverUtil.turnBy(angleToTurn);
    minorAngleCorrection();
  }

  /**
   * Assume start at an angle close to the reall value. Perform us localization and face toward the
   * closest wall.
   */
  private static void minorAngleCorrection() {
    // perform small turn and locate the average Min distance angle.
    DriverUtil.turnBy(-1 * HALF_SMALL_ROTATION);
    DriverUtil.setSpeed(SMALL_ROTATE_SPEED);
    ultraSonicController.reset();
    long initialTime = System.currentTimeMillis();
    DriverUtil.turnBy(SMALL_ROTATION);
    long totalTic = System.currentTimeMillis() - initialTime;
    long minTic = ultraSonicController.getAvgMinDistIndex() - initialTime;
    double angleToTurn = 0;
    angleToTurn = (double) (minTic - totalTic) * SMALL_ROTATION / (totalTic);
    DriverUtil.turnBy(angleToTurn);
  }

  /**
   * Assume the robot faces a wall. backup until a distance of a tile distance.
   */
  private static void backup() {
    ultraSonicController.reset();
    Main.sleepFor(DEFAULT_SLEEP_TIME);
    double curDist = ultraSonicController.getCurDist();
    DriverUtil.setSpeed(ROTATE_SPEED);
    DriverUtil.moveStraightFor(curDist + US_SENSOR_CENTER_OFFSET - TILE_SIZE, true);
  }
}
