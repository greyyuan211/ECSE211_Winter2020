# Lab 3 Localization

See instructions on MyCourses and read the general guidelines on the
[website](https://mcgill-dpm.github.io/website/).
