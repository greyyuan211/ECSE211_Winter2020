package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import java.util.ArrayList;

public class Navigation {

	/**
	 * The US controller thread to poll and provide information.
	 */
	private static Thread ultrasonicThread;

	/**
	 * The CS controller thread to poll and provide information.
	 */
	private static Thread colorThread;

	/**
	 * Initialize the location to the default starting parameter in the odometer.
	 */
	public static void initializeOdometer() {
		odometer.setX(sX);
		odometer.setY(sY);
		odometer.setTheta(sT);
	}

	/**
	 * Convert grid coordinate to actual coordinate (cm).
	 * 
	 * @param ind
	 * @return actual distance (cm)
	 */
	public static double gridToCord(int ind) {
		return ind * TILE_SIZE;
	}

	/**
	 * Perform a operation to travel to a specified location based on the odometer.
	 * and user input
	 * 
	 * @param x
	 * @param y
	 */
	public static void travelTo(double x, double y) {
		double[] xyt = odometer.getXyt();
		double curX = xyt[0];
		double curY = xyt[1];
		double deltaX = x - curX;
		double deltaY = y - curY;
		double angle = Math.toDegrees(Math.atan2(deltaY, deltaX));
		double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
		turnTo(angle);
		MoveController.moveStraightFor(distance);
	}

	/**
	 * Rotate to the given angle base on the current odometer data
	 * 
	 * @param angle
	 */
	public static void turnTo(double angle) {
		double[] xyt = odometer.getXyt();
		double currentTheta = xyt[2];
		double angleToturn = angle - currentTheta;
		// get the minimum angle
		if (angleToturn > 180) {
			angleToturn = angleToturn - 360.0;
		} else if (angleToturn < -180.0) {
			angleToturn = 360.0 + angleToturn;
		}
		MoveController.turnBy(angleToturn);
	}

	/**
	 * Round the position after a color sensor localization
	 */
	private static void roundPosition() {
		double[] xyt = odometer.getXyt();
		double roundedX = TILE_SIZE * Math.round(xyt[0] / TILE_SIZE);
		double roundedY = TILE_SIZE * Math.round(xyt[1] / TILE_SIZE);
		double roundedTheta = (RIGHT_ANGLE_ROTATION * Math.round(xyt[2] / RIGHT_ANGLE_ROTATION)) % 360;
		odometer.setX(roundedX);
		odometer.setY(roundedY);
		odometer.setTheta(roundedTheta);
		System.out.println("X: " + roundedX);
		System.out.println("Y: " + roundedY);
		System.out.println("T: " + roundedTheta);
	}

	/**
	 * Localize using the light sensor
	 */
	public static void colorLocalization(boolean red) {
		// Start the us controller
		MoveController.setSpeed(CS_ROTATE_SPEED);
		colorController = new ColorController(red);
		colorThread = new Thread(colorController);
		colorThread.start();
		MoveController.turnBy(FULL_ROTATION);
		int totalTick = colorController.getTotalTick();
		ArrayList<Integer> ticks = colorController.getBlackTicks();
		double offset = 2;
		while (ticks.size() < 4) {
			MoveController.moveStraightFor(offset);
			colorController.reset();
			MoveController.turnBy(FULL_ROTATION);
			totalTick = colorController.getTotalTick();
			ticks = colorController.getBlackTicks();
			int sign = offset > 0.0 ? -1 : 1;
			offset = sign * Math.abs(offset + 2);
		}
		tickLocalize(ticks, totalTick);
		colorController.stopController();
		MoveController.turnBy(CS_SMALL_ROTATION);
		ColorController.turnUntilLine(true);
		roundPosition();
		
	}

	/**
	 * Localized based on tick received from the color sensor.
	 * 
	 * @param an    array list of tick where black line was detected.
	 * @param total amount of tick made throughout the 360 degree turn.
	 */
	private static void tickLocalize(ArrayList<Integer> ticks, int totalTick) {
		// Perform x correction
		double angle = CS_ANGLE_OFFSET + (ticks.get(0) * FULL_ROTATION) / totalTick;
		double deltaTheta = getDTheta(ticks.get(0), ticks.get(2), totalTick);
		double angletoTurn = angle + deltaTheta;
		MoveController.turnBy(angle);
		MoveController.turnBy(deltaTheta);
		double offset = COLOR_SENSOR_CENTER_OFFSET * Math.cos(Math.toRadians(deltaTheta));
		MoveController.moveStraightFor(-offset);
		// Perform the y correction
		angle = CS_ANGLE_OFFSET + (ticks.get(1) * FULL_ROTATION) / totalTick;
		deltaTheta = getDTheta(ticks.get(1), ticks.get(3), totalTick);
		angletoTurn = angle - angletoTurn;
		MoveController.turnBy(angletoTurn);
		MoveController.turnBy(deltaTheta);
		offset = COLOR_SENSOR_CENTER_OFFSET * Math.cos(Math.toRadians(deltaTheta));
		MoveController.moveStraightFor(-offset);
	}

	/**
	 * Perform the computation and return the delta angle. uses angle between the
	 * two tick from color sensor
	 * 
	 * @param first    tick that black line was detected
	 * @param opposite tick that black line was detected
	 * @param total    amount of tick made
	 * @return the delta angle from the first line position to facing the line
	 */
	private static double getDTheta(int tick1, int tick2, int totalTick) {

		double dtheta = (tick2 - tick1) * 360.0 / totalTick;
		if (dtheta > 180.0) {
			dtheta = dtheta - 360.0;
		}
		dtheta /= 2.0;
		return dtheta;
	}

	/**
	 * The initial Localization. Uses ultrasonic detection twice and find the min
	 * and travel distance based on sensor data.
	 */
	public static void initialLocalization() {
		// Start the us controller
	    ultraSonicController = new UltraSonicController();
	    ultrasonicThread = new Thread(ultraSonicController);
		ultrasonicThread.start();
		// perform the following operation 2 time. Face the closest wall and backup
		// until a suitable
		// distance based on the us sensor
		for (int i = 0; i < 2; i++) {
			faceTheClosestWall();
			backup();
		}
		// The robot now face one of the two wall. If it is the right most wall. Perform
		// a 90 degree
		// right turn. Else perform a 180 degree turn (2*90 degree). We first assume
		// case 1.
		MoveController.turnBy(-RIGHT_ANGLE_ROTATION);
		// Case 2
		if (ultraSonicController.getCurDist() < DISTANCE_THRESHOLD) {
			MoveController.turnBy(-RIGHT_ANGLE_ROTATION);
		}
		ultraSonicController.reset();
		ultraSonicController.stopController();
	}

	/**
	 * Helper method to face towards the closest wall. Perform a 360 sweep to turn
	 * to the aggregate angle and a slow 60 degree sweep to turn get a accurate
	 * turn.
	 */
	private static void faceTheClosestWall() {
		// perform 360 turn and locate the approximate angle and use minor correction to
		// determine the
		// exact angle.
		ultraSonicController.reset();
		MoveController.setSpeed(ROTATE_SPEED);
		MoveController.turnBy(FULL_ROTATION);
		int totalTic = ultraSonicController.getTotalTick();
		int minTic = ultraSonicController.getAvgMinDistIndex();
		double angleToTurn = 0;
		// locate the angle away from the start position.
		angleToTurn = ((double) minTic) * FULL_ROTATION / totalTic;
		if (angleToTurn > 180.0) {
			angleToTurn = angleToTurn - 360.0;
		} // perform the turn
		MoveController.turnBy(angleToTurn);
		minorAngleCorrection();
	}

	/**
	 * Assume start at an angle close to the reall value. Perform us localization
	 * and face toward the closest wall.
	 */
	private static void minorAngleCorrection() {
		// perform small turn and locate the average Min distance angle.
		MoveController.turnBy(-1 * HALF_SMALL_ROTATION);
		MoveController.setSpeed(SMALL_ROTATE_SPEED);
		ultraSonicController.reset();
		MoveController.turnBy(SMALL_ROTATION);
		int totalTic = ultraSonicController.getTotalTick();
		int minTic = ultraSonicController.getAvgMinDistIndex();
		double angleToTurn = 0;
		angleToTurn = (double) (minTic - totalTic) * SMALL_ROTATION / (totalTic);
		MoveController.turnBy(angleToTurn);
	}

	/**
	 * Assume the robot faces a wall. backup until a distance of a tile distance.
	 */
	private static void backup() {
		ultraSonicController.reset();
		Main.sleepFor(DEFAULT_SLEEP_TIME);
		double curDist = ultraSonicController.getCurDist();
		MoveController.setSpeed(ROTATE_SPEED);
		MoveController.moveStraightFor(curDist + US_SENSOR_CENTER_OFFSET - TILE_SIZE);
	}
}
