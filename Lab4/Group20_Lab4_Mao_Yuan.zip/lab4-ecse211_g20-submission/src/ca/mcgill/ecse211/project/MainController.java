package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.ROTATE_SPEED;
import static ca.mcgill.ecse211.project.Resources.odometer;
import static ca.mcgill.ecse211.project.Resources.colorController;
import static ca.mcgill.ecse211.project.Resources.FULL_ROTATION;;

public class MainController implements Runnable {

	/**
	 * Option for selecting mode.
	 */
	private int option = -1;

	/**
	 * Records of all the maps given from the lab document.
	 */
	private int[][][] paths = { { { 3, 2 }, { 2, 2 }, { 2, 3 }, { 3, 1 } },
			{ { 1, 3 }, { 2, 2 }, { 3, 3 }, { 3, 2 }, { 2, 1 } }, { { 1, 3 }, { 2, 2 }, { 3, 3 }, { 3, 2 }, { 2, 1 } },
			{ { 2, 2 }, { 1, 3 }, { 3, 3 }, { 3, 2 }, { 2, 1 } }, { { 2, 1 }, { 3, 2 }, { 3, 3 }, { 1, 3 }, { 2, 2 } },
			{ { 1, 2 }, { 2, 3 }, { 2, 1 }, { 3, 2 }, { 3, 3 } } };

	/**
	 * Constructor for the class. Set the option entered by the user.
	 * 
	 * @param option for setup
	 */
	public MainController(int option) {
		this.option = option;
	}

	/**
	 * Run the corresponding mode based on the option.
	 * 
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		if (this.option == 0) {
			modeA();
		} else if (this.option == 1) {
			modeB();
		} else if (this.option == 2) {
			modeC();
		} else if (this.option == 3) {
			calibrateAngle();
		}

	}

	/**
	 * For testing the initial localization.
	 */
	private void modeA() {
		Navigation.initialLocalization();
	}

	/**
	 * Mode for testing the color localization.
	 */
	private void modeB() {
		Navigation.colorLocalization(false);
	}

	/**
	 * Primary mode for lab
	 */
	private void modeC() {
		Navigation.initialLocalization();
		MoveController.setSpeed(ROTATE_SPEED);
		new Thread(odometer).start();
		Navigation.initializeOdometer();
		new Thread(new Display()).start();
		int count = 1;
		for (int[] path : paths[1]) {
			if(count%3==0)Navigation.colorLocalization(true);
		    double x = Navigation.gridToCord(path[0]);
			double y = Navigation.gridToCord(path[1]);
			Navigation.travelTo(x, y);
			count++;
		}
		Navigation.colorLocalization(true);
		colorController.stopController();
	}

	/**
	 * Wheel angle and odometer calibration mode. Perform 2 full rotation turn and
	 * test the accuracy of the turn.
	 */
	private void calibrateAngle() {
		new Thread(odometer).start();
		Navigation.initializeOdometer();
		new Thread(new Display()).start();
		MoveController.setSpeed(ROTATE_SPEED);
		MoveController.turnBy(2 * FULL_ROTATION);
	}

}
