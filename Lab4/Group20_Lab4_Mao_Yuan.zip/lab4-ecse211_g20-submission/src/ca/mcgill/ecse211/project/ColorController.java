package ca.mcgill.ecse211.project;

import static ca.mcgill.ecse211.project.Resources.*;
import lejos.hardware.lcd.LCD;
import lejos.robotics.Color;
import lejos.robotics.SampleProvider;
import java.util.ArrayList;

public class ColorController implements Runnable {

  /**
   * 
   */
  private SampleProvider value = colorSensor.getMode("Red");

  private static float[] colordata = new float[colorSensor.sampleSize()];


  /**
   * Record the total tick count started from the begining of the thread start Increment every
   * measurement to keep track of time elapse.
   */
  private int totalTick = 0;

  /**
   * The tick where the first black was detected.
   */
  private int blackTick = -1;

  /**
   * The number of measurement the black tick is associated with. Used to calculate the middle
   * point.
   */
  private int width = 0;

  /**
   * For the big board.
   */
  private static double boardColor;

  private static double range;
  /**
   * A boolean to keep end the thread.
   */
  private volatile boolean active = true;

  /**
   * Record the ticks that black stripe occured.
   */
  ArrayList<Integer> blackTicks = new ArrayList<Integer>();

  public ColorController(boolean red) {
    // TODO Auto-generated constructor stub
    if (red) {
      colorSensor.setCurrentMode("Red");
      boardColor = BLUE_BOARD;
      range = BLUE_BOARD_RANGE;
    } else {
      boardColor = BROWN_BOARD;
      range = BROWN_BOARD_RANGE;
    }
  }

  /**
   * Constantly poll the sensor and sleep
   */
  public void run() {
    while (active) {
      readAndUpdate();
      Main.sleepFor(CS_POLL_SLEEP_TIME);
    }
  }

  /**
   * Reset the controller parameters for the next use
   */
  public void reset() {
    active = true;
    blackTicks = new ArrayList<Integer>();
    width = 0;
    blackTick = -1;
    totalTick = 0;
  }

  /**
   * Stop the controller by setting the active flag
   */
  public void stopController() {
    active = false;
  }

  /**
   * Read the color sensor and update the value
   */
  private void readAndUpdate() {
    colorSensor.fetchSample(colordata, 0);
    float cid = colordata[0] * 100;
    System.out.println(cid);
    boolean black = !isWithinInterval(cid, boardColor, 100);
    LCD.clear();
    if (black) {
      if (width == 0) {
        blackTick = totalTick;
      }
      width++;
    } else {
      if (width >= 1) {
        int tick = blackTick + width;
        blackTicks.add(tick);
        blackTick = -1;
        width = 0;
      }
    }
    totalTick++;
  }

  /**
   * Get the total tick of the color sensor since the last reset.
   * 
   * @return totaltick
   */
  public int getTotalTick() {
    return totalTick;
  }

  /**
   * Return the ticks that black occured
   * 
   * @return the tick
   */
  public ArrayList<Integer> getBlackTicks() {
    return blackTicks;
  }

  /**
   * The moveUntilLine method moves forward or backward until a line is detected.
   * 
   * @param forward : true to move forward, false to move backward
   * @param delay : delay in ms to wait until after the line is detected
   * @param pos : 0 if the axis to be crossed is the x-axis, 1 for y
   */
  public static void moveUntilLine(boolean forward) {
    if (forward) {
      leftMotor.forward();
      rightMotor.forward();
    } else {
      leftMotor.backward();
      rightMotor.backward();
    }
    colorSensor.fetchSample(colordata, 0);
    double cid = colordata[0];
    // Let the motors go forward/backward until the sensor senses a black line.
    while (!isWithinInterval(cid, 13, 0.5)) {
      colorSensor.fetchSample(colordata, 0);
      cid = colordata[0];
    }
    // The delay allows the robot to move slightly past the black line before
    // stopping,
    // to avoid accidentally reading the same line twice in a row.
    // Main.sleepFor(DEFAULT_SLEEP_TIME);

    leftMotor.stop(true);
    rightMotor.stop();
  }

  /**
   * The moveUntilLine method moves turn clockwise or counter clockwise until a line is detected.
   * 
   * @param clockwise : true to move clockwise, false to move counter-clockwise
   */
  public static void turnUntilLine(boolean clockwise) {
    MoveController.setSpeed(SMALL_ROTATE_SPEED);
    if (clockwise) {
      leftMotor.forward();
      rightMotor.backward();
    } else {
      leftMotor.backward();
      rightMotor.forward();
    }
    // Let the motors go forward/backward until the sensor senses a black line.
    colorSensor.fetchSample(colordata, 0);
    double cid = colordata[0];
    // Let the motors go forward/backward until the sensor senses a black line.
    while (isWithinInterval(cid, boardColor, range)) {
      colorSensor.fetchSample(colordata, 0);
      cid = colordata[0];
    }
    leftMotor.stop(true);
    rightMotor.stop();
    MoveController.setSpeed(FORWARD_SPEED);
  }

  /**
   * check if value is within the interval
   * 
   * @param value
   * @param center
   * @param offset
   * @return value within interval
   */
  private static boolean isWithinInterval(double value, double center, double offset) {
    return value >= center - offset && value <= center + offset;
  }
}
